import AccountsManager from "@/components/AccountsManager";

export default function TrashPage() {
  const Component = AccountsManager as any;
  return (
    <div>
      <h1 className="mb-1 text-2xl font-black">🗑️ سلة المحذوفات</h1>
      <p className="mb-5 text-sm font-semibold text-slate-500">الحذف هنا ناعم — لا يختفي شيء من قاعدة البيانات. استرجع أي حساب للمخزون، أو احذفه نهائياً فقط إن لم يكن له سجل إيجارات.</p>
      <Component trash={true} />
    </div>
  );
}
